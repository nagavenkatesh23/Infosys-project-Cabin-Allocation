const dbLayer = require("../model/account")
const validator = require("../utilities/validator")
const CabinDeletion = require("../model/cabinDeletion")
const InsertIntoCabin = require("../model/insertIntoCabin")

let service = {}

service.insertScript = () => {
    return dbLayer.insertScript().then((data) => {
        return data
    })
}

//======================================== Login validation ======================================================
service.validateLogin = (loginObj) => {
    // console.log(loginObj)
    return dbLayer.getUser(loginObj.userName).then((response) => {
        // console.log(response)
        if (!response) {
            let err = new Error("User does not exist")
            err.status = 401
            throw err
        }
        else if (response.password != loginObj.password) {
            let err = new Error("Incorrect password")
            err.status = 401
            throw err
        } else {
            let temp = [];
            temp.push(response.empName);
            temp.push(response.designation);
            return temp
        }
    })
}

//Login
service.getdesignation = (username, designation) => {
    return dbLayer.getdesignation(username, designation).then((data) => {
        return data
    })
}

//=================================== admin part for deleted details =============================================

//To get deleted employee & cabin details based on cabin number
service.getDeletedDetails = (cabinNumber) => {
    // console.log(cabinNumber)
    return dbLayer.getDeletedDetails(cabinNumber).then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin Number details found")
            err.status = 404
            throw err
        }
    })
}

//To get deleted employee & cabin details based on Employee Id
service.getEmpdetails = (empId) => {
    return dbLayer.getEmpDeletedDetails(empId).then((data) => {
        // console.log(data)
        if (data) {
            return data
        } else {
            let err = new Error("No EmployeeId details found")
            err.status = 404
            throw err
        }
    })
}

//To get deleted employee & cabin details based on Employee Name
service.getEmpname = (empName) => {
    return dbLayer.getEmpname(empName).then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No Employee Name details found")
            err.status = 404
            throw err
        }
    })
}

//================================== cabin details based on floor ==================================================

service.getCabinDetails = (cabinFloor) => {
    return dbLayer.getCabinDetails(cabinFloor).then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin  details found")
            err.status = 404
            throw err
        }
    })
}

//================================== cabin details based on floor,wing,status ======================================

service.getCabinDetail = (cabinFloor, cabinWing, allocationStatus) => {
    return dbLayer.getCabinDetail(cabinFloor, cabinWing, allocationStatus).then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin  details found")
            err.status = 404
            throw err
        }
    })
}

//====================================== cabin allocation by Manager ============================================

//Allocate cabin
service.allocateCabins = (cabinAllocatedDetails) => {
    return dbLayer.allocateCabins(cabinAllocatedDetails).then((data) => {
        if (data == null) {
            let err = new Error("allocation failed");
            err.status = 400;
            throw err;
        } else return data
    })
}

//update or shifting cabin
service.updateCabins = (empId, cabinUpdateDetails) => {
    return dbLayer.updateCabins(empId, cabinUpdateDetails).then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("Cabin details not updated")
            err.status = 400
            throw err
        }
    })
}

//========================================== Deallocating cabin ====================================================
//checkEmpdetails
service.deallocateCabins = (empId, cabinNumber) => {
    // console.log(empId,cabinNumber)
    return dbLayer.checkEmpdetails(empId).then((data) => {
        if (data != null) {
            let CabinDeletionObj = new CabinDeletion(data)
            // console.log(CabinDeletionObj);
            // return dbLayer.insertIntoDeletedDb(data.empId,data.empName,data.userName,data.allocatedDate,cDate,data.designation,data.cabinNumber,data.stream)
            return dbLayer.insertIntoDeletedDb(CabinDeletionObj)
                .then((res) => {
                    if (res) {
                        // let status = "Empty"
                        let InsertIntoCabinObj = new InsertIntoCabin(empId, cabinNumber)
                        // console.log(InsertIntoCabinObj);
                        return dbLayer.insertIntoCabinDb(InsertIntoCabinObj)
                            .then((resp) => {
                                if (resp) {
                                    return dbLayer.deallocateCabins(empId).then((response) => {
                                        // console.log(resp)
                                        if (response) return response
                                        else {
                                            let err = new Error("Cannot De-Allocate the cabin");
                                            err.status = 500;
                                            throw err;
                                        }
                                    })
                                }
                                else {
                                    return "Insertion Failed in the Cabin DataBase"
                                }

                            })
                    }
                    else {
                        return "Insertion Failed in Deleted DataBase"
                    }

                })
        }
        else {
            return "No Details Found"
        }
    })
}

//================================ cabin details based on ground floor ========================================
service.getGroundCabinDetails = () => {
    return dbLayer.getGroundCabinDetails().then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin details found")
            err.status = 404
            throw err
        }
    })
}

//================================ cabin details based on level 1 floor ========================================
service.getLevelOneCabinDetails = () => {
    return dbLayer.getLevelOneCabinDetails().then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin details found")
            err.status = 404
            throw err
        }
    })
}

//================================ cabin details based on level 2 floor =========================================
service.getLevelTwoCabinDetails = () => {
    return dbLayer.getLevelTwoCabinDetails().then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin details found")
            err.status = 404
            throw err
        }
    })
}

//=====================================Cabin Adding or updating or deleting by Admin================================

//Insert or add cabins
service.createCabin = (createCabinObj) => {
    return dbLayer.createCabin(createCabinObj).then((data) => {
        if (data == null) {
            let err = new Error("allocation failed");
            err.status = 400;
            throw err;
        } else return data
    })
}

// delete cabin --delete
//Delete cabin, if their is filled status then shift and then delete
service.deleteCabins = (cabinNumber) => {
    return dbLayer.getCabins(cabinNumber).then((cabinObj) => {
        //  console.log("aaa"+cabinObj)
        if (cabinObj[0].allocationStatus == "Filled") {
            // console.log(cabinObj);
            return "cabin is already allocated to other user cannot be deleted"
        }
        else {
            return dbLayer.deleteCabins(cabinNumber).then((resp) => {
                // console.log(resp)
                if (resp) return resp
                else {
                    let err = new Error("Cannot Delete the cabin");
                    err.status = 500;
                    throw err;
                }
            })
        }
    })
    // return dbLayer.deallocateCabins(empId).then((resp) => {
    //     // console.log(resp)
    //     if (resp) return resp
    //     else {
    //         let err = new Error("Cannot Delete the cabin");
    //         err.status = 500;
    //         throw err;
    //     }
    // })

}

//====================================== Other Users Search ================================================

//  getting details based on the employee id
service.getEmpCabinDetails = (empId) => {
    return dbLayer.getEmpdetails(empId).then((data) => {
        return dbLayer.getEmpCabinDetails(empId).then((data1) => {
            //    console.log("In service"+data+data1)
            let a = []
            a.push(data)
            a.push(data1)
            // console.log(a[0])
            if (a[0] != null) {
                return a
            } else {
                let err = new Error("No details found for the given empId " + "" + empId)
                err.status = 404
                throw err
            }
        })
    })
}

//  getting all the details of available Employees
service.getuserDetails = () => {
    return dbLayer.getuserDetails().then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No users details found")
            err.status = 404
            throw err
        }
    })
}

// getting all the details of available cabin
service.getCabinDetails = () => {
    return dbLayer.getCabinDetails().then((data) => {
        if (data) {
            return data
        } else {
            let err = new Error("No cabin details found")
            err.status = 404
            throw err
        }
    })
}

//==================================== search for cabin number in user portal =======================================
service.getUserCabinDetails = (cabinNumber) => {
    return dbLayer.getUserEmpdetails(cabinNumber).then((data) => {
        return dbLayer.getUserCabinDetails(cabinNumber).then((data1) => {
            //    console.log("In service"+data+data1)
            let a = []
            a.push(data)
            a.push(data1)
            // console.log(a[0])
            if (a[0] != null) {
                return a
            } else {
                let err = new Error("No details found for the given cabinNumber " + "" + cabinNumber)
                err.status = 404
                throw err
            }
        })
    })
}

//========================= search for Employees in user portal based on employee name =========================
service.getEmpName = (empName) => {
    return dbLayer.getUserEmpdetailsName(empName).then((data1) => {
        if (data1 != null) {
            return dbLayer.getUserCabinDetailsName(data1.cabinNumber).then((data) => {
                // console.log("In service" + data1)
                let a = []
                a.push(data1)
                a.push(data)
                // console.log(a[0])
                if (a[0] != null) {
                    return a
                } else {
                    let err = new Error("No details found for the given employee name " + "" + empName)
                    err.status = 404
                    throw err
                }
            })
        }
        else {
            let err = new Error("Enter correct Employee Name")
            err.status = 404
            throw err
        }

    })
}

//-----------------------------------------------------------------------------------------------------------

//Routing to update Password
service.updatePassword = (username, dPassword, password) => {
    // console.log(username,dPassword,password)
    return dbLayer.updatePassword(username, dPassword, password).then((data) => {
        if (data) {
            return data
        }
        else {
            let err = new Error("Check UserName or Password")
            err.status = 400
            throw err
        }

    })
}

//-----------------------------------------------------------------------------------------------------------


module.exports = service