const express = require('express');
const routing = express.Router();
const service = require("../service/account");
const create = require('../model/dbsetup')
const CabinAllocation = require('../model/cabinallocation')
const createCabin = require('../model/createCabin')
const UpdatePassword = require('../model/passwordUpdate')

//============================================ DB set up =======================================================
routing.get("/setupDB", (req, res, next) => {
    create.setupDb().then((data) => {
        if (data) {
            res.status(201)
            res.json({ message: "Inserted " + data + " document in database" })
        }
    })
})

//======================================== DB setup for deleted =================================================
routing.get("/setupdeletedDB", (req, res, next) => {
    create.setupdeletedDB().then((data) => {
        if (data) {
            res.status(201)
            res.json({ message: "Inserted " + data + " document in database" })
        }
    })
})

//==================================== DB setup for cabin Details ================================================
routing.get("/setupCabinDB", (req, res, next) => {
    create.setupCabinDB().then((data) => {
        if (data) {
            res.status(201)
            res.json({ message: "Inserted " + data + " document in database" })
        }
    })
})

//===================================================================================================================

//Routing for login
routing.post("/login", (req, res, next) => {
    let loginObj = req.body
    // console.log(loginObj);
    service.validateLogin(loginObj).then((resp) => {
        // console.log(resp)
        if (resp) {
            res.status(200)
            res.json({ resp, resp })
            // res.json({ resp })
        }
    }).catch((err) => {
        next(err)
    })
})

//Routing details
routing.get('/login/:username/:designation', (req, res, next) => {
    let username = req.params.username;
    let designation = req.params.designation;
    service.getdesignation(username, designation).then((employeeDetails) => {
        res.status(200)
        res.json(employeeDetails)
    }).catch((err) => {
        next(err);
    })
})

//=================================== admin part for deleted details =============================================

//Routing to get deleted cabin details based on cabin number 
routing.get('/admincabin/:cabinNumber', (req, res, next) => {
    let cabinNumber = req.params.cabinNumber;
    // console.log(cabinNumber)
    service.getDeletedDetails(cabinNumber).then((employeeDetails) => {
        res.status(200)
        res.json(employeeDetails)
    }).catch((err) => {
        next(err)
    })
})

//Routing to get deleted cabin details based on employee Id 
routing.get("/adminempid/:empId", (req, res, next) => {
    // console.log(req.params.empId)
    let empId = req.params.empId;
    // console.log(empId)
    service.getEmpdetails(empId).then((employeeDetails) => {
        res.status(200)
        res.json(employeeDetails)
    }).catch((err) => {
        next(err)
    })
})

//Routing to get deleted cabin details based on employee name 
routing.get("/adminename/:empName", (req, res, next) => {
    let empName = req.params.empName;
    service.getEmpname(empName).then((employeeDetails) => {
        // console.log(employeeDetails)
        res.status(200)
        res.json(employeeDetails)
    }).catch((err) => {
        next(err)
    })
})

//============================ cabin details based on floor  (Manager Part) =======================================

routing.get('/cabin/:cabinFloor', (req, res, next) => {
    let cabinfloor = req.params.cabinFloor;
    service.getCabinDetails(cabinfloor).then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})

//======================= cabin details based on cabin floor,wing,status  (Manager) ===============================

routing.get('/cabinStatus/:cabinFloor/:cabinWing/:allocationStatus', (req, res, next) => {
    let cabinwing = req.params.cabinWing;
    let cabinfloor = req.params.cabinFloor;
    let AllocationStatus = req.params.allocationStatus;
    service.getCabinDetail(cabinfloor, cabinwing, AllocationStatus).then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})

//==================================  cabin allocation by Manager ================================================

//Allocate cabin
routing.post('/allocateCabin', (req, res, next) => {
    const cabinAllocatedDetails = new CabinAllocation(req.body);
    // console.log(cabinAllocatedDetails)
    service.allocateCabins(cabinAllocatedDetails).then((cabinAllocatedDetails) => {
        res.json(cabinAllocatedDetails);
    }).catch((err) => next(err))
})

//update or shifting cabin
routing.put("/cabinUpdate/:empId", (req, res, next) => {
    const cabinUpdateDetails = new CabinAllocation(req.body);
    let empId = req.params.empId
    service.updateCabins(empId, cabinUpdateDetails).then((data) => {
        res.json({ message: "cabin updated with number : " + data })
    }).catch((err) => {
        next(err)
    })
})

//Deallocating cabin
routing.delete("/cabinDeallocate/:empId/:cabinNumber", (req, res, next) => {
    let empId = req.params.empId
    let cabinNumber = req.params.cabinNumber
//    console.log(empId,cabinNumber);
    service.deallocateCabins(empId,cabinNumber).then((data) => {
        res.json("De-allocated cabin for empId : ")
    }).catch((err) => {
        next(err)
    })
})

//=================================== cabin details based on ground floor ================================================
routing.get('/GcabinDetails', (req, res, next) => {
    service.getGroundCabinDetails().then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})

//=================================== cabin details based on level 1 floor ============================================
routing.get('/L1cabinDetails', (req, res, next) => {
    service.getLevelOneCabinDetails().then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})

//=================================== cabin details based on level 2 floor ============================================
routing.get('/L2cabinDetails', (req, res, next) => {
    service.getLevelTwoCabinDetails().then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})


//=========================== Cabin Adding or updating or deleting by Admin =======================================

// Insert or add cabins
routing.post('/createCabin', (req, res, next) => {
    const createCabinObj = new createCabin(req.body);
    // console.log(cabinAllocatedDetails)
    service.createCabin(createCabinObj).then((createCabinObj) => {
        res.json(createCabinObj);
    }).catch((err) => next(err))
})

//Update or shifting cabin details 

// same as manager update

//Delete cabin, if their is filled status then shift and then delete
routing.delete("/deleteCabins/:cabinNumber", (req, res, next) => {
    let cabinNumber = req.params.cabinNumber
    service.deleteCabins(cabinNumber).then((data) => {
        // console.log("in routing"+data)
        // res.json({ message: "Deleted cabin for cabin number : " + cabinNumber })
        res.json({ data })
    }).catch((err) => {
        next(err)
    })
})

//========================================== Other Users Search ============================================

// getting details based on the employee id
routing.get('/user/:empid', (req, res, next) => {
    let empId = req.params.empid;
    service.getEmpCabinDetails(empId).then((data) => {
        res.status(200)
        res.json(data)
        // console.log(data)
    }).catch((err) => {
        next(err)
    })
})

// getting all the details of available employee
routing.get('/employeeDetails', (req, res, next) => {
    service.getuserDetails().then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})

// getting all the details of available cabin
routing.get('/cabinDetails', (req, res, next) => {
    service.getCabinDetails().then((data) => {
        res.status(200)
        res.json(data)
    }).catch((err) => {
        next(err)
    })
})

//==========================================================================================================

//search for cabin number in user portal based on cabin number
routing.get('/user1/:cabinnumber', (req, res, next) => {
    let cabinNumber = req.params.cabinnumber;
    // console.log(cabinNumber)
    service.getUserCabinDetails(cabinNumber).then((data) => {
        res.status(200)
        res.json(data)
        // console.log(data)
    }).catch((err) => {
        next(err)
    })
})

//search for cabin number in user portal based on employee name
routing.get('/user2/:empName', (req, res, next) => {
    let empName = req.params.empName;
    service.getEmpName(empName).then((data) => {
        if(data!=null)
        {
        res.status(200)
        res.json(data)
        console.log(data)
        }
        else{
            res.json("Invalid Employee Name")
        }

    }).catch((err) => {
        next(err)
    })
    

})

//---------------------------------------------------------------------------------------

//Routing to update Password
routing.put("/updatePassword/:username/:dpassword/:password", (req, res, next) => {
    // let Obj = new UpdatePassword(req.body)
    let username = req.params.username
    let password = req.params.password
    let dPassword = req.params.dpassword
    service.updatePassword(username, dPassword, password).then((data) => {
        res.json({ message: "New Password is updated for the userName : " + data })
    }).catch((err) => {
        next(err)
    })
})

//---------------------------------------------------------------------------------------


module.exports = routing;