const mongoose = require("mongoose")
mongoose.Promise = global.Promise;
const Schema = mongoose.Schema
mongoose.set("useCreateIndex", true)

let collection = {};

const userDbSchema = Schema(
    {
        "empId": {
            type: Number,
            required: true,
            unique: true
        },
        "empName": {
            type: String,
            required: true,
        },
        "userName": {
            type: String,
            required: true,
            unique: true
        },
        "password": {
            type: String,
            required: true
        },
        "designation": {
            type: String,
            required: true
        },
        "cabinNumber": {
            type: String,
            required: true,
            unique: true
            // default: []
        },
        "allocatedDate": {
            type: Date,
            required: true
        },
        "stream": {
            type: String,
            required: true
        }
    },
    { collection: "EmployeeDetails" }
)

const deletedDbSchema = Schema(
    {
        "empId": {
            type: Number,
            required: true,
            unique: true
        },
        "empName": {
            type: String,
            required: true,
        },
        "userName": {
            type: String,
            required: true,
            unique: true
        },
        "allocatedDate": {
            type: Date,
            required: true
        },
        "deallocatedDate": {
            type: Date,
            required: true
        },
        "designation": {
            type: String,
            required: true
        },
        "cabinNumber": {
            type: String,
            required: true,
            unique: true
        },
        "stream": {
            type: String,
            required: true
        }
        // default: []
    },
    { collection: "Deleted" }
)

const cabinDbSchema = Schema(
    {
        "cabinNumber": {
            type: String,
            //min: 80,
            required: true
        },
        "cabinWing": {
            type: String,
            required: true,

        },
        "cabinFloor": {
            type: String,
            required: true,

        },
        "allocationStatus": {
            type: String,
            required: true,

        },
        "allocatedUser": {
            type: Number
            // required: true
        }
    },
    { collection: "Cabins" }
)


collection.getEmpDetails = () => {
    return mongoose.connect("mongodb://localhost:27017/cabinAllocation_DB", { useNewUrlParser: true }).then((db) => {
        return db.model("EmployeeDetails", userDbSchema)
    }).catch((err) => {
        // console.log(err.message);
        let error = new Error("Could not connect to database")
        error.status = 500;
        throw error;
    })
}

collection.getDeletedDetails = () => {
    return mongoose.connect("mongodb://localhost:27017/cabinAllocation_DB", { useNewUrlParser: true }).then((db) => {
        return db.model("Deleted", deletedDbSchema)
    }).catch((err) => {
        // console.log(err.message);
        let error = new Error("Could not connect to database")
        error.status = 500;
        throw error;
    })
}

collection.getCabinDetails = () => {
    return mongoose.connect("mongodb://localhost:27017/cabinAllocation_DB", { useNewUrlParser: true })
        .then((db) => {
            return db.model("Cabins", cabinDbSchema)
        })
        .catch((err) => {
            // console.log(err.message);
            let error = new Error("Could not connect to database")
            error.status = 500;
            throw error;
        })
}
//===================================================================================================================
collection.getEmpCabinDetails = () => {
    return mongoose.connect("mongodb://localhost:27017/cabinAllocation_DB", { useNewUrlParser: true }).then((db) => {
        return (db.model("EmployeeDetails", userDbSchema)
            // db.model("Cabins", cabinDbSchema)
        )
    }).catch((err) => {
        // console.log(err.message);
        let error = new Error("Could not connect to database")
        error.status = 500;
        throw error;
    })
}

module.exports = collection;