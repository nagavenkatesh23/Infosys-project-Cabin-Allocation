// Inserting into deleted db
class CabinDeletion {
    constructor(obj) {
        this.empId = obj.empId;
        this.empName = obj.empName;
        this.userName = obj.userName;
        this.designation = obj.designation;
        this.cabinNumber = obj.cabinNumber;
        this.allocatedDate = obj.allocatedDate;
        this.deallocatedDate = new Date();
        this.stream = obj.stream;
    }
}

module.exports = CabinDeletion;