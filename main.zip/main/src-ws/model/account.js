const collection = require("../utilities/connection")

let model = {}

//this function is used to insert the data
model.insertScript = () => {
    return collection.getCollection().then((collection) => {
        return collection.deleteMany().then((data) => {
            return collection.insertMany(initialData).then((response) => {
                if (response && response.length > 0) {
                    return response.length
                } else {
                    let err = new Error("Script insertion failed")
                    err.status = 500
                    throw new Error
                }
            })
        })
    })
}

//to get cabin details
model.getCabins = (cabinNumber) => {
    return collection.getCabinDetails().then((collection) => {
        return collection.find({ cabinNumber: cabinNumber }, { _id: 0 }).then((data) => {
            return data
        })
    })
}

//Login
model.getdesignation = (username, designation) => {
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ userName: username }, { _id: 0, userName: 1, designation: 1 })
            .then((data) => {
                if (data.designation == designation) {
                    return true
                }
                else {
                    return false
                }
            })
    })
}

//to get employee details
model.getUser = (username) => {
    // console.log(username)
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ userName: username }, { _id: 0, userName: 1, password: 1, designation: 1, empName: 1 })
            .then((data) => {
                // console.log("aaa" + data)
                return data
            })
    })
}

//To get deleted employee & cabin details based on cabin number
model.getDeletedDetails = (cabinNumber) => {
    // console.log(cabinNumber)
    return collection.getDeletedDetails().then((collection) => {
        return collection.findOne({ cabinNumber: cabinNumber }, { _id: 0 }).then((data) => {
            return data
        })
    })
}

//To get deleted employee & cabin details based on Employee Id
model.getEmpDeletedDetails = (empId) => {
    // console.log("in model aaaa"+empId)
    return collection.getDeletedDetails().then((collection) => {
        return collection.findOne({ empId: empId }, { _id: 0 }).then((data) => {
            // console.log("in model empdetails"+data)
            return data
        })
    })
}

//To get deleted employee & cabin details based on Employee Name
model.getEmpname = (empName) => {
    return collection.getDeletedDetails().then((collection) => {
        return collection.findOne({ empName: empName }, { _id: 0 }).then((data) => {
            return data
        })
    })
}

//=================================== cabin details based on floor ===============================================

model.getCabinDetails = (cabinFloor) => {
    return collection.getCabinDetails().then((collection) => {
        return collection.find({ cabinFloor: cabinFloor }, { _id: 0 }).then((data) => {
            return data
        })
    })
}

//================================ cabin details based on floor,wing,status ====================================

model.getCabinDetail = (cabinFloor, cabinWing, allocationStatus) => {
    return collection.getCabinDetails().then((collection) => {
        return collection.find({ cabinFloor: cabinFloor, cabinWing: cabinWing, allocationStatus: allocationStatus }, { _id: 0 }).then((data) => {
            return data
        })
    })
}

//====================================== cabin allocation by manager ==========================================

//Allocate cabin
model.allocateCabins = (collectObj) => {
    return collection.getEmpDetails().then((collection) => {
        return collection.create(collectObj).then((data) => {
            if (data) {
                return true
            } else {
                return false
            }
        })
    })
}

//update or shifting cabin
model.updateCabins = (empId, cabinUpdateDetails) => {
    // console.log(empId, cabinUpdateDetails)
    return collection.getEmpDetails().then((collection) => {
        // console.log(collection)
        // console.log(empId)
        // console.log(typeof cabinUpdateDetails)
        return collection.updateOne({ empId: empId }, { cabinNumber: cabinUpdateDetails.cabinNumber }).then((data) => {
            // console.log(data)
            if (data.nModified > 0)
                return cabinUpdateDetails.cabinNumber
            else
                return null
        })
    })
}

// Checking whether the Employee is there in the users db or not
model.checkEmpdetails = (empId) => {
    // console.log("in model aaaa"+empId)
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ empId: empId }, { _id: 0, password: 0 }).then((data) => {
            // console.log("in model empdetails"+data)
            return data
        })
    })
}

// insert into deleted db
model.insertIntoDeletedDb = (CabinDeletionObj) => {
    return collection.getDeletedDetails().then((collection) => {        
        return collection.create(CabinDeletionObj).then((data) => {
            // console.log(data);
            if (data.cabinNumber) {
                return true
            } else {
                return false
            }
        })
    })
}

// insertion into cabin db
model.insertIntoCabinDb = (InsertIntoCabinObj) => {
    return collection.getCabinDetails().then((collection) => {
        return collection.create(InsertIntoCabinObj).then((data) => {
            if (data) {
                return true
            } else {
                return false
            }
        })
    })
}

//deallocateCabins
model.deallocateCabins = (empId) => {
    return collection.getEmpDetails().then((collection) => {
        return collection.deleteOne({ empId: empId }, { runValidators: true }).then((resp) => {
            // console.log(resp)
            if (resp.deletedCount > 0) return resp
            else return null
        })
    })
}

//================================ cabin details based on ground floor =========================================
model.getGroundCabinDetails = () => {
    // console.log("in model aaaa"+empId)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({cabinFloor:"G"}, { _id: 0 }).then((data) => {
            console.log("in model cabin details" + data)
            return data
        })
        // return collection
    })
}

//================================ cabin details based on level 1 floor ========================================
model.getLevelOneCabinDetails = () => {
    // console.log("in model aaaa"+empId)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({cabinFloor:"L1"}, { _id: 0 }).then((data) => {
            console.log("in model cabin details" + data)
            return data
        })
        // return collection
    })
}

//================================ cabin details based on level 2 floor =========================================
model.getLevelTwoCabinDetails = () => {
    // console.log("in model aaaa"+empId)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({cabinFloor:"L2"}, { _id: 0 }).then((data) => {
            console.log("in model cabin details" + data)
            return data
        })
        // return collection
    })
}


//================================ Cabin Adding or updating or deleting by Admin ===============================

//Insert or add cabins
model.createCabin = (createCabinObj) => {
    return collection.getCabinDetails().then((collection) => {
        return collection.create(createCabinObj).then((data) => {
            if (data) {
                return true
            } else {
                return false
            }
        })
    })
}

// delete cabin -- delete
//Delete cabin, if their is filled status then shift and then delete
model.deleteCabins = (cabinNumber) => {
    return collection.getCabinDetails().then((collection) => {
        return collection.deleteOne({ cabinNumber: cabinNumber }, { runValidators: true }).then((resp) => {
            // console.log(resp)
            if (resp.deletedCount > 0) return resp
            else return null
        })
    })
}


//========================================= Other Users Search ===================================================

//  getting details based on the employee id
model.getEmpCabinDetails = (allocatedUser) => {
    // console.log(allocatedUser)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({ allocatedUser: allocatedUser }, { _id: 0 }).then((data) => {
            //console.log("in model" + data)
            return data
        })
    })
}

//  getting details based on the employee id
model.getEmpdetails = (empId) => {
    // console.log("in model aaaa"+empId)
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ empId: empId }, { _id: 0, password: 0, cabinNumber: 0 }).then((data) => {
            // console.log("in model empdetails"+data)
            return data
        })
    })
}

//  getting all the details of available employees
model.getuserDetails = () => {
    // console.log("in model aaaa"+empId)
    return collection.getEmpDetails().then((collection) => {
        return collection.find({}, { _id: 0, password: 0 }).then((data) => {
            // console.log("in model empdetails"+data)
            return data
        })
        // return collection
    })
}

// getting all the details of available cabin
model.getCabinDetails = () => {
    // console.log("in model aaaa"+empId)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({}, { _id: 0 }).then((data) => {
            // console.log("in model cabin details" + data)
            return data
        })
        // return collection
    })
}

//=========================================== Cabin Details ==========================================================
//search for cabin number in user portal
model.getUserCabinDetails = (cabinNumber) => {
    // console.log(cabinNumber)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({ cabinNumber: cabinNumber }, { _id: 0 }).then((data) => {
            // console.log("in model" + data)
            return data
        })
    })
}
model.getUserEmpdetails = (cabinNumber) => {
    // console.log("in model aaaa"+empId)
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ cabinNumber: cabinNumber }, { _id: 0, password: 0, cabinNumber: 0 }).then((data) => {
            // console.log("in model empdetails"+data)
            return data
        })
    })
}
model.getUserCabinDetailsName = (cabinNumber) => {
    // console.log(cabinNumber)
    return collection.getCabinDetails().then((collection) => {
        return collection.find({ cabinNumber: cabinNumber }, { _id: 0 }).then((data) => {
            // console.log("in model" + data)
            return data
        })
    })
}

//search for Employees in user portal based on employee name
model.getUserEmpdetailsName = (empName) => {
    // console.log("in model aaaa"+empId)
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ empName: empName }, { _id: 0, password: 0 }).then((data) => {
            // console.log("in model empdetails"+data)
            return data
        })
    })
}

//===================================================================================================================

//to update Password
model.updatePassword = (userName, dPassword, password) => {
    return collection.getEmpDetails().then((collection) => {
        return collection.findOne({ userName: userName  }, { _id: 0, userName: 1, password: 1 }).then((data) => {
            // console.log("In Model")
            // console.log(data)
            // console.log(dPassword,password)
            if (data.userName == userName && data.password == dPassword) {
                return collection.updateOne({ userName: userName }, { $set: { password: password } },
                    { runValidators: true }).then((response) => {
                        if (response.nModified > 0)
                            return userName
                        else
                            return null
                    })
            }
            else{
            return null
            }
        })
    })
}

//====================================================================================================================

module.exports = model
