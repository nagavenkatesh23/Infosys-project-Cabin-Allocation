class PasswordUpdate {
    constructor(obj) {
        this.userName = obj.userName;
        this.password = obj.password;
        this.dPassword = obj.dPassword;
    }
}

module.exports = PasswordUpdate;