const collection = require("../utilities/connection")

const userDb = [{
    empId: 123456,
    empName: "Monica",
    userName: "monica04.manic",
    password: "manic",
    designation: "admin",
    cabinNumber: "G-B01",
    allocatedDate:"06-06-2015",
    stream: "UI-MERN",
},
{
    empId: 564786,
    empName: "Mona",
    userName: "mona2.mona",
    password: "mona23",
    designation: "admin",
    cabinNumber: "L1-B12",
    allocatedDate:"06-06-2015",
    stream: "UI-MERN",
},
{
    empId: 148054,
    empName: "Mini",
    userName: "mini04.mini",
    password: "aaaaaa",
    designation: "manager",
    cabinNumber: "L1-A01",
    allocatedDate:"06-06-2015",
    stream: "BI"
},
{
    empId: 564433,
    empName: "Venkatesh",
    userName: "venky23.venky",
    password: "asdfgh",
    designation: "manager",
    cabinNumber: "G-A23",
    allocatedDate: "08-08-2018",
    stream: "UI-MERN"
},
{
    empId: 456789,
    empName: "Amarnath",
    userName: "kotla.amar",
    password: "khgkhg",
    designation: "user",
    cabinNumber: "G-A01",
    allocatedDate: "09-09-2019",
    stream: "SAP"
}
]

const deletedDb = [
    {
        empId: 456789,
        empName: "Amarnath",
        userName: "kotla.amar",
        // password: "",
        allocatedDate: "05-03-2020",
        deallocatedDate: "05-05-2020",
        designation: "user",
        cabinNumber: "G-A01",
        stream: "SAP"
    },
    {
        empId: 564786,
        empName: "Mona",
        userName: "mona2.mona",
        // password: "mona23",
        allocatedDate: "06-06-2020",
        deallocatedDate: "07-07-2020",
        designation: "admin",
        cabinNumber: "L1-B12",
        stream: "UI-MERN",
    }
]

const cabinDb = [
    {
        cabinNumber: "G-A01",
        cabinWing: "A",
        cabinFloor: "G",
        allocationStatus: "Filled",
        allocatedUser: 456789
    },
    {
        cabinNumber: "G-A02",
        cabinWing: "A",
        cabinFloor: "G",
        allocationStatus: "Empty",
        allocatedUser: null
    },
    {
        cabinNumber: "G-A23",
        cabinWing: "A",
        cabinFloor: "G",
        allocationStatus: "Filled",
        allocatedUser: 564433
    },
    {
        cabinNumber: "G-B02",
        cabinWing: "B",
        cabinFloor: "G",
        allocationStatus: "Empty",
        allocatedUser: null
    },
    {
        cabinNumber: "G-B01",
        cabinWing: "B",
        cabinFloor: "G",
        allocationStatus: "Filled",
        allocatedUser: 123456
    },
    {
        cabinNumber: "L1-A01",
        cabinWing: "A",
        cabinFloor: "L1",
        allocationStatus: "Filled",
        allocatedUser: 148054
    },
    {
        cabinNumber: "L1-A02",
        cabinWing: "A",
        cabinFloor: "L1",
        allocationStatus: "Empty",
        allocatedUser: null
    },
    {
        cabinNumber: "L1-B01",
        cabinWing: "B",
        cabinFloor: "L1",
        allocationStatus: "Filled",
        allocatedUser: 564911
    },
    {
        cabinNumber: "L1-B02",
        cabinWing: "B",
        cabinFloor: "L1",
        allocationStatus: "Empty",
        allocatedUser: null
    },
    {
        cabinNumber: "L1-B12",
        cabinWing: "B",
        cabinFloor: "L1",
        allocationStatus: "Filled",
        allocatedUser: 564786
    },
    {
        cabinNumber: "L2-A01",
        cabinWing: "A",
        cabinFloor: "L2",
        allocationStatus: "Filled",
        allocatedUser: 564568
    },
    {
        cabinNumber: "L2-A02",
        cabinWing: "A",
        cabinFloor: "L2",
        allocationStatus: "Empty",
        allocatedUser: null
    },
    {
        cabinNumber: "L2-B01",
        cabinWing: "B",
        cabinFloor: "L2",
        allocationStatus: "Filled",
        allocatedUser: 564321
    },
    {
        cabinNumber: "L2-B02",
        cabinWing: "B",
        cabinFloor: "L2",
        allocationStatus: "Empty",
        allocatedUser: null
    }

]

let dbsetup = {}

dbsetup.setupDb = () => {
    return collection.getEmpDetails().then((collection) => {
        return collection.deleteMany().then((data) => {
            return collection.insertMany(userDb).then((response) => {
                if (response && response.length > 0) {

                    return response.length
                } else {
                    let err = new Error("Script insertion failed")
                    err.status = 500
                    throw new Error
                }
            })
        })
    })
}

dbsetup.setupdeletedDB = () => {
    // console.log("haiiii123")
    return collection.getDeletedDetails().then((collection) => {
        return collection.deleteMany().then((data) => {
            return collection.insertMany(deletedDb).then((response) => {
                if (response && response.length > 0) {
                    return response.length
                } else {
                    let err = new Error("Script insertion failed")
                    err.status = 500
                    throw new Error
                }
            })
        })
    })
}

dbsetup.setupCabinDB = () => {
    return collection.getCabinDetails().then((collection) => {
        console.log(collection)
        return collection.deleteMany().then((data) => {
            return collection.insertMany(cabinDb).then((response) => {
                if (response && response.length > 0) {
                    return response.length
                } else {
                    let err = new Error("Script insertion failed")
                    err.status = 500
                    throw new Error
                }
            })
        })
    })
}

module.exports = dbsetup
