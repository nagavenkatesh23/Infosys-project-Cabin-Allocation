import React, { Component } from '../node_modules/react';
import './App.css';
import User from './component/user';
import Login from './component/login';
import CabinDetails from './component/allcabindetails';
import DeletedDetails from './component/deletedDetails';
import OtherUser from './component/otheruser';
import { BrowserRouter as Router, Route, Redirect, Switch, Link } from "react-router-dom";
import NewUser from './component/newUser';
import "bootstrap/dist/css/bootstrap.min.css";

class App extends Component {
  state = {
    userName: "",
    showLogin: true
  }

  changeUser = (data) => {
    this.setState({ userName: data }, () => console.log(this.state.userName))
  }

  removeLogin = () => {
    // console.log("aaaa")
    this.setState({ showLogin: false })
  }

  //========================================= Nav Bar ======================================================
  render() { 
    return (
      <Router>
        <div>
          <nav className="navbar navbar-expand-lg navbar-dark bg-dark p-3">
            <span className="navbar-brand font-weight-bolder">
              <Link style={{ color: "white" }} to="/otheruser">Welcome Infoscion</Link>
            </span>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="collapsibleNavbar">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item">
                  <Link className="nav-link font-weight-bold" to="/otheruser">
                    Home
                </Link>
                </li>
                <li className="nav-item mr-2">
                  {!this.state.userName && <Link className="nav-link font-weight-bold" to="/login">
                    Login
                </Link>}
                </li>
                <li className="nav-item mr-2" onClick={() => this.setState({ showLogin: true })}>
                  {this.state.userName && <Link className="nav-link font-weight-bold" to="/login">
                    Logout
                </Link>}
                </li>
              </ul>
            </div>
          </nav>
          <Switch>
            <Route exact path="/user" component={User} />
            <Route exact path="/login" render={({ match }) => <Login removeLogin={this.removeLogin} match={match}
              changeUser={this.changeUser}
              showLogin={this.state.showLogin} />} />
            <Route exact path="/cabinDetails" component={CabinDetails} />
            <Route exact path="/newUser" component={NewUser} />
            <Route exact path="/otheruser" component={OtherUser} />
            <Route exact path="/" component={OtherUser} />
            <Route exact path="*" render={() => (<Redirect to="./otheruser" />)} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
