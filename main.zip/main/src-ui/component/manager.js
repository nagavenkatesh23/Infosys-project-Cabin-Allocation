import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import User from "./user"
import CabinDetails from "./allcabindetails";
import DeletedDetails from "./deletedDetails"
import 'bootstrap/dist/css/bootstrap.min.css';
import AllCabinDetails from "./allcabindetails";
import AllocateCabin from "./allocatecabin";
import DeAllocateCabin from "./deallocatecabin";

class Manager extends Component {
    constructor(props) {
        super(props);
        this.state = {
            allocateCabin: false,
            deAllocateCabin: false,
            // viewDetails: false,
            viewCabinDetails: false
        }
    }
    
    //prevent page from refreshing from submit
    admin = event => {
        event.preventDefault();
    }

//==================================== Form for Manager Page ===================================================
    render() {
        if (this.state.allocateCabin != false) {
            return <AllocateCabin></AllocateCabin>;  // change in future
        }
        else if (this.state.deAllocateCabin != false) {
            return <DeAllocateCabin></DeAllocateCabin>;  // change in future
        }
        else if (this.state.viewCabinDetails != false) {
            return <AllCabinDetails></AllCabinDetails>;
        }
        else {
            return (
                // <h1>Hello</h1>
                <React.Fragment>
                    <div className="container-fluid">
                    <h1 style={{ color: "yellow" }}><i>{this.props.uname}</i></h1>
                        <div className="row mt-4">
                            <div className="col-lg-2  offset-lg-5">
                                <form onSubmit={this.admin}>
                                    <div className="form-group">
                                        <button name="add" type="submit" className="btn btn-info btn-block" onClick={() => { this.setState({ allocateCabin: true }) }}>Allocate Cabin</button>
                                        <button name="delete" type="submit" className="btn btn-info btn-block" onClick={() => { this.setState({ deAllocateCabin: true }) }}>De-allocate Cabin</button>
                                        <button name="cabin" type="submit" className="btn btn-info btn-block" onClick={() => { this.setState({ viewCabinDetails: true }) }}>View Cabin Details</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </React.Fragment>
            )
        }
    }
}

export default Manager;