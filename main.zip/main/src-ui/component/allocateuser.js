import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Admin from "./admin"
import GAllocateTable from "./Gallocatetable.js"
const url1 = "http://localhost:1050/allocateCabin"

export default class AllocateUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            // availableCabin: [],
            form: {
                empId: "",
                empName: "",
                userName: "",
                password: "",
                designation: "",
                cabinNumber: "",
                stream: ""
            },
            formValid: {
                empId: false,
                empName: false,
                userName: false,
                password: false,
                designation: false,
                cabinNumber: false,
                stream: false,
                buttonActive: false
            },
            formErrorMessage: {
                empId: "",
                empName: "",
                userName: "",
                password: "",
                designation: "",
                cabinNumber: "",
                stream: ""
            },
            errorMessage: "",
            successMessage: "",
            goBack: false,
        }
    }

    handleSubmit = event => {
        event.preventDefault();
        this.getUserDetails();
    }

    getUserDetails = () => {
        // let empId = this.state.form.empId
        let url = `http://localhost:1050/allocateCabin`
        // console.log("in axios"+empId)
        axios.post(url, this.state.form)
            .then(res => {
                this.setState({ availableCabin: res.data })
                this.setState({ errorMessage: "" });
            })
            .catch(err => {
                let errMsg = err.response ? err.response.data.message : "Server Error"
                this.setState({ errorMessage: errMsg })
                this.setState({ successMessage: "" });
            })
    }
    handleChange = (event) => {
        console.log(event.target.name)
        console.log(event.target.value)
        const name = event.target.name;
        const value = event.target.value;
        this.setState({ form: { ...this.state.form, [name]: value } });
        this.validateField(name, value);
    };

    validateField = (fieldName, value) => {
        let message = ""
        let validity = false
        switch (fieldName) {
            case "empId":
                let regex = new RegExp(/^[1-9][0-9]{5}$/);
                value === "" ? message = "field required" : regex.test(value) ? message = "" : message = "Please enter valid empId"
                break;
            case "empName":
                let regex1 = new RegExp(/^[A-z]{2,}$/);
                value === "" ? message = "field required" : regex1.test(value) ? message = "" : message = "Please enter valid name"
                break;
            case "userName":
                let regex2 = new RegExp(/^[A-z0-9]{5,}\.[A-z0-9]{3,}$/);
                value === "" ? message = "field required" : regex2.test(value) ? message = "" : message = "username should be of 8 characters minimum"
                break;
            case "password":
                let regex3 = new RegExp(/^[A-z0-9\*\$\#\@\!\&\^\%\s]{5,}$/);
                value === "" ? message = "field required" : regex3.test(value) ? message = "" : message = "password invalid!password must be of length 5"
                break;
            case "designation":
                let regex4 = new RegExp(/^[A-z]{2,}$/);
                value === "" ? message = "field required" : regex4.test(value) ? message = "" : message = "Designation invalid!password must be of length 6"
                break;

            case "cabinNumber":
                let regex5 = new RegExp(/^(G|L1|L2)-[A-Z][0-9]{2,3}$/);
                value === "" ? message = "field required" : regex5.test(value) ? message = "" : message = "Please enter valid cabin number"
                break;
            case "stream":
                let regex6 = new RegExp(/^[A-z]{2}-?[A-z]{2,}$/);
                value === "" ? message = "field required" : regex6.test(value) ? message = "" : message = "Please enter valid Stream"
                break;
            default:
                break;
        }

        let formErrorMessageObj = this.state.formErrorMessage
        formErrorMessageObj[fieldName] = message
        this.setState({ formErrorMessage: formErrorMessageObj })
        validity = message ? false : true
        let formvalidObj = this.state.formValid
        formvalidObj[fieldName] = validity
        formvalidObj.buttonActive = formvalidObj.empId && formvalidObj.empName && formvalidObj.userName
            && formvalidObj.password && formvalidObj.designation && formvalidObj.cabinNumber && formvalidObj.stream
        this.setState({ formValid: formvalidObj })
        console.log(this.state.formValid.buttonActive)
    }

    //==========================================================================================

    render() {
        if (this.state.goBack) {
            return <GAllocateTable />
        }
        return (
            <React.Fragment>
                <div className="container mt-5">
                    <div className="mt-4">
                        <div>
                            <button className='float-right btn btn-success' name="goBack" onClick={() => this.setState({ goBack: true })}>Go Back</button>
                        </div>
                    </div>
                    <div className="row mt-5">
                        <div className="col-lg-5 offset-lg-2">
                            <div className="card bg-card bg-dark text-light ">
                                <div className="card-header bg-custom text-center"><h3>Allocate Cabin</h3></div>
                                <div className="card-body bg-dark text-light">
                                    <form onSubmit={this.handleSubmit}>
                                        <div className="form-group">
                                            <label htmlFor="empId">Employee Id</label>
                                            <input className="form-control" type="text" name="empId" id="empId" placeholder="enter employee Id" value={this.state.form.empId} onChange={this.handleChange} />
                                            <span name="empIdError" className="text-danger">
                                                {this.state.formErrorMessage.empId}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="empName">Employee Name</label>
                                            <input type="text" name="empName" id="empName" className="form-control" placeholder="enter employee name" value={this.state.form.empName} onChange={this.handleChange} />
                                            <span name="empNameError" className="text-danger">
                                                {this.state.formErrorMessage.empName}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="userName">Username </label>
                                            <input type="text" name="userName" id="userName" className="form-control" placeholder="enter Username" value={this.state.form.userName} onChange={this.handleChange} />
                                            <span name="userNameError" className="text-danger">
                                                {this.state.formErrorMessage.userName}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="passWord">Password</label>
                                            <input type="password" name="password" id="password" className="form-control"
                                                placeholder="Enter Password" value={this.state.form.password} onChange={this.handleChange} />
                                            <span name="passwordError" className="text-danger">
                                                {this.state.formErrorMessage.password}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="designation">Designation</label>
                                            <select id="designation" className="form-control"  >
                                                <option value="" disabled selected hidden>Select</option>
                                                <option value1="user">User</option>
                                                <option value2="admin">Admin</option>
                                            </select>
                                            <span name="DesignationError" className="text-danger">
                                                {this.state.formErrorMessage.Designation}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="cabinNumber">Cabin Number</label>
                                            <input type="text" name="cabinNumber" id="cabinNumber" className="form-control" placeholder="Enter Cabin Number" value={this.state.form.cabinNumber} onChange={this.handleChange} />
                                            <span name="cabinNumberError" className="text-danger">
                                                {this.state.formErrorMessage.cabinNumber}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="stream">Stream</label>
                                            <select id="stream" className="form-control">
                                                <option value="" disabled selected hidden>Select</option>
                                                <option value1="bi">BI</option>
                                                <option value2="ui-mean">UI-MEAN</option>
                                                <option value3="ui-mern">UI-MERN</option>
                                                <option value4="sap">SAP</option>
                                                <option value5="os">OS</option>
                                            </select>
                                            <span name="streamError" className="text-danger">
                                                {this.state.formErrorMessage.stream}
                                            </span>
                                        </div>
                                        <button name="submit" type="submit" className="btn btn-primary btn-block" disabled={!this.state.formValid.buttonActive}>Submit</button>
                                    </form>
                                    <span name="errorMessage" className="text-danger text-bold">
                                        {this.state.errorMessage}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}


