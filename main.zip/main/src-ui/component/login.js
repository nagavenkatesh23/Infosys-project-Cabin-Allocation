import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import User from "./user"
import Admin from "./admin"
import Manager from "./manager"
import NewUser from "./newUser"
import OtherUser from "./otheruser";
import { Link } from "react-router-dom"
const url = "http://localhost:1050/login";

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                userName: "",
                password: ""
            },
            formErrorMessage: {
                userName: "",
                password: ""
            },
            formValid: {
                userName: false,
                password: false,
                buttonActive: false
            },
            // disp:"",
            errorMessage: "",
            designation: "",
            session: ""
        };
    }

    //================================== Axios for login details ====================================================
    loginEmployee = event => {
        event.preventDefault();  //Prevent page from refreshing after submit
        // console.log(this.state.form)
        axios.post(url, this.state.form)
            .then(response => {
                // console.log(response)
                // console.log(response.data.resp[0])
                this.state.session = response.data.resp[0]
                //   this.state.disp = response.data;
                this.props.changeUser(response.data.resp[0])
                this.setState({ designation: response.data.resp[1], errorMessage: "" }, () => this.props.removeLogin());
                this.setState({ userName: "", password: "" })
            })
            .catch(err => {
                // console.log(err.message, err.response)
                let errMsg = err.response ? err.response.data.message : "Server Error"
                // console.log(errMsg)
                this.setState({ errorMessage: errMsg, designation: "" })
            })
    };

    handleChange = event => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        //console.log(name,value)
        const { form } = this.state;
        this.setState({ form: { ...form, [name]: value } });
        this.validateField(name, value);
    };

    //Validation for username and password
    validateField = (fieldName, value) => {
        let message = "";
        let validity = false;
        let name = fieldName;
        switch (name) {
            case "userName":
                let regex = new RegExp(/^[A-z0-9]{5,}\.[A-z0-9]{3,}$/);
                value === "" ? message = "field required" : regex.test(value) ? message = "" : message = "username should be of 8 characters minimum"
                break
            case "password":
                let regex1 = new RegExp(/^[A-z0-9\*\$\#\@\!\&\^\%\s]{5,}$/);
                value === "" ? message = "field required" : regex1.test(value) ? message = "" : message = "password invalid!password must be of length 5"
                break
            default:
                break
        }

        let formErrorMessagesObj = this.state.formErrorMessage;
        formErrorMessagesObj[name] = message;
        this.setState({ formErrorMessage: formErrorMessagesObj });
        validity = message == "" ? true : false;
        let formValidityObj = this.state.formValid;
        formValidityObj[name] = validity;
        formValidityObj.buttonActive = (formValidityObj.userName && formValidityObj.password);
        this.setState({ formValid: formValidityObj })
    };
//========================== Login form and navigation based on users designation ===================================================
    render() {
        // {console.log(this.props.showLogin)}

        // if(this.props.showLogin=="trueee")
        // {
        //     this.state.form.userName=""
        //     this.state.form.password=""
        // }
        // {console.log(this.state.form.userName)}

        if (!this.props.showLogin) {
            if (this.state.designation == "admin") {
                return <Admin uname={this.state.session} />;
            }
            else if (this.state.designation == "user") {
                return <OtherUser uname={"Hello " + this.state.session}></OtherUser>;
            }
            else if (this.state.designation == "manager") {
                return <Manager uname={"Hello " + this.state.session}></Manager>;
            }
        }
        else {
            return (
                <div className="Login" >
                    <div className="row">
                        <div className="col-md-3 offset-md-2" >
                            <br />
                            <div className="card bg-dark text-light">
                                <div className="card-header bg-custom text-center"><h3>Login</h3></div>
                                <div className="card-body bg-dark text-light">
                                    <form onSubmit={this.loginEmployee}>
                                        <div className="form-group">
                                            <label htmlFor="userName">Username</label>
                                            <input type="text" name="userName" id="userName" className="form-control" placeholder="username" value={this.state.form.userName} onChange={this.handleChange} />
                                            <span name="userNameError" className="text-danger">
                                                {this.state.formErrorMessage.userName}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="password">Password</label>
                                            <input type="password" name="password" id="password" className="form-control" placeholder="password" value={this.state.form.password} onChange={this.handleChange} />
                                            <span name="passwordError" className="text-danger">
                                                {this.state.formErrorMessage.password}
                                            </span>
                                        </div>
                                        <button name="login" type="submit"
                                            className="btn btn-primary btn-block"
                                            disabled={!this.state.formValid.buttonActive}>Login</button>
                                        <br />
                                        <Link to="/NewUser" style={{ color: "cyan" }}>Reset Password</Link>
                                    </form>
                                    {/* <span >{this.state.successMessage}</span> */}
                                    <span name="errorMessage" className="text-danger text-bold">
                                        {this.state.errorMessage}
                                    </span>
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
    }
}

export default Login;
