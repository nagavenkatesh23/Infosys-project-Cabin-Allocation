import React, { Component } from "react";
import axios from "axios";
import User from "./user"
import AdminCabinDetails from "./allcabindetailsAdmin";
import DeletedDetails from "./deletedDetails"
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css'
const url = "http://localhost:1050/login";

class Admin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            addCabin: false,
            deleteCabin: false,
            viewDetails: false,
            viewDeletedDetails: false,
            viewCabinDetails: false,
            uname: "Hello " + this.props.uname
        }
    }
    admin = event => {
        event.preventDefault();
    }

    render() {
        if (this.state.addCabin != false) {
            return <User></User>;  // change in future
        }
        else if (this.state.deleteCabin != false) {
            return <User></User>;  // change in future
        }
        else if (this.state.viewDetails != false) {
            return <User></User>;
        }
        else if (this.state.viewDeletedDetails != false) {
            return <DeletedDetails></DeletedDetails>;
        }
        else if (this.state.viewCabinDetails != false) {
            // return <AdminCabinDetails></AdminCabinDetails>
            return <AdminCabinDetails></AdminCabinDetails>;
            // return <AdminCabinDetails uname={this.state.uname}></AdminCabinDetails>;
        }
        else {
            return (
                // <h1>Hello</h1>
                <React.Fragment>
                    <div className="container-fluid">
                        {
                            this.state.uname == "Hello undefined" ? null :
                            <h1 style={{ color: "yellow" }}><i>{this.state.uname}</i></h1>
                        }
                        <div className="row mt-4">
                            <div className="col-lg-2  offset-lg-5">
                                <form onSubmit={this.admin}>
                                    <div className="form-group">
                                        <button name="add" type="submit" className="btn btn-info btn-block">Add Cabin</button>
                                        <button name="delete" type="submit" className="btn btn-info btn-block">Delete Cabin</button>
                                        <button name="view" type="submit" className="btn btn-info btn-block" onClick={() => { this.setState({ viewDetails: true }) }}>View Details</button>
                                        <button name="deleted" type="submit" className="btn btn-info btn-block" onClick={() => { this.setState({ viewDeletedDetails: true }) }}>View Deleted Details</button>
                                        <button name="cabin" type="submit" className="btn btn-info btn-block" onClick={() => { this.setState({ viewCabinDetails: true }) }}>View Cabin Details</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </React.Fragment>
            )
        }
    }
}

export default Admin;