import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import User from "./user"
import Admin from "./admin"
import Manager from "./manager"
import { Link } from "react-router-dom";
const url = "http://localhost:1050/updatePassword";

class NewUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                userName: "",
                defaultPassword: "",
                password: ""
            },
            formErrorMessage: {
                userName: "",
                defaultPassword: "",
                password: ""
            },
            formValid: {
                userName: false,
                defaultPassword: false,
                password: false,
                buttonActive: false
            },
            // disp:"",
            errorMessage: "",
            successMessage: ""
        };
    }

    loginNewUser = event => {
        event.preventDefault();  //Prevent page from refreshing after submit
        // console.log(this.state.form)
       let  url=`http://localhost:1050/updatePassword/${this.state.form.userName}/${this.state.form.defaultPassword}/${this.state.form.password}`
        axios.put(url)
            .then(response => {
                // console.log(response.data.message)
                //   this.state.disp = response.data;
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                // console.log(this.state.successMessage)
            })
            .catch(err => {
                let errMsg = err.response ? err.response.data.message : "Server Error"
                this.setState({ errorMessage: errMsg, successMessage: "" })
            })
    };

    handleChange = event => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        //console.log(name,value)
        const { form } = this.state;
        this.setState({ form: { ...form, [name]: value } });
        this.validateField(name, value);
    };

//Validation for username and password
    validateField = (fieldName, value) => {
        let message = "";
        let validity = false;
        let name = fieldName;
        switch (name) {
            case "userName":
                let regex = new RegExp(/^[A-z0-9]{5,}\.[A-z0-9]{3,}$/);
                value === "" ? message = "field required" : regex.test(value) ? message = "" : message = "username should be of 8 characters minimum"
                break
            case "defaultPassword":
                let regex1 = new RegExp(/^[\w\!\@\#\$\%\^\&\*]{5,}$/);
                value === "" ? message = "field required" : regex1.test(value) ?message = "" : message = "Default Password invalid!password must be of length 5"
                break
            case "password":
                // let regex2 = new RegExp(/^[\w\!\@\#\$\%\^\&\*]{8,}$/);
                let regex2 = new RegExp(/^[A-z]{1}[A-z0-9]{1,6}[!\@\#\$\%\^\&\*]{1}$/)
                value === "" ? message = "field required" : regex2.test(value) ? message = "" : message = "New password must start with uppercase and shd consists of special characters"
                break
            default:
                break
        }
        
        let formErrorMessagesObj = this.state.formErrorMessage;
        formErrorMessagesObj[name] = message;
        this.setState({ formErrorMessage: formErrorMessagesObj });
        validity = message == "" ? true : false;
        let formValidityObj = this.state.formValid;
        formValidityObj[name] = validity;
        formValidityObj.buttonActive = (formValidityObj.userName && formValidityObj.password);
        this.setState({ formValid: formValidityObj })
    };

//=========================== Form to Reset Password ======================================================
    render() {

        if (this.state.successMessage == "admin") {
            return <Admin></Admin>;
        }
        else if (this.state.successMessage == "user") {
            return <User></User>;
        }
        else if (this.state.successMessage == "manager") {
            return <Manager></Manager>;
        }

        else {
            return (
                <div className="NewUser">
                    <div className="row">
                        <div className="col-md-3 offset-md-4">
                            <br />
                            <div className="card bg-dark text-light">
                                <div className="card-header bg-custom text-center"><h3>Reset Password</h3></div>
                                <div className="card-body bg-dark text-light">
                                    <form onSubmit={this.loginNewUser}>
                                        <div className="form-group">
                                            <label htmlFor="userName">Username</label>
                                            <input type="text" name="userName" id="userName" className="form-control" 
                                            placeholder="username" value={this.state.form.userName}
                                             onChange={this.handleChange} />
                                            <span name="userNameError" className="text-danger">
                                                {this.state.formErrorMessage.userName}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="defaultPassword">Old Password</label>
                                            <input type="password" name="defaultPassword" id="defaultPassword"
                                             className="form-control" placeholder="old password" 
                                             value={this.state.form.defaultPassword} onChange={this.handleChange} />
                                            <span name="defaultPassword" className="text-danger">
                                                {this.state.formErrorMessage.defaultPassword}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="password">New Password</label>
                                            <input type="password" name="password" id="password" 
                                            className="form-control" placeholder="new password"
                                             value={this.state.form.password} onChange={this.handleChange} />
                                            <span name="password" className="text-danger">
                                                {this.state.formErrorMessage.password}
                                            </span>
                                        </div>
                                        <button name="submit" type="submit" className="btn btn-primary btn-block" disabled={!this.state.formValid.buttonActive}>Submit</button>
                                    </form>
                                    <span name="errorMessage" className="text-danger text-bold">
                                        {this.state.successMessage}
                                    </span>
                                    <span name="errorMessage" className="text-danger text-bold">
                                        {this.state.errorMessage}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
    }
}

export default NewUser;