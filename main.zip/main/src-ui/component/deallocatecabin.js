import React, { Component } from "react";
// import axios from "axios";
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import image from "./img12.jpg"
import Manager from "./manager"

class DeAllocateCabin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            deallocateCabin: []
        }
    }

    render() {
        if (this.state.deallocateCabin == null) {
            return <Manager></Manager>
        }
        return (
            <React.Fragment>
                <div className="container mt-5">
                    <div className="mt-4">
                        <div>
                            <button name="goBack" type="submit" className="float-right btn btn-warning" onClick={() => { this.setState({ deallocateCabin: null }) }}>Go Back</button>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="card-deck">
                                <div className="card ">
                                    <div className="card-header"><h4 className="text-center">Ground Floor</h4></div>
                                    <div className="card-body">
                                        <img width="100%" height="180" src={image} alt="nthg" />
                                    </div>
                                    <div className="card-footer">
                                        <button type="button" className="btn btn-primary btn-block">De-Allocate Cabin</button>
                                    </div>
                                </div>
                                <div className="card ">
                                    <div className="card-header"><h4 className="text-center">Level 1</h4></div>
                                    <div className="card-body">
                                        <img width="100%" height="180" src={image} alt="nthg" />
                                    </div>
                                    <div className="card-footer">
                                        <button type="button" className="btn btn-primary btn-block">De-Allocate Cabin</button>
                                    </div>
                                </div>
                                <div className="card ">
                                    <div className="card-header"><h4 className="text-center">Level 2</h4></div>
                                    <div className="card-body">
                                        <img width="100%" height="180" src={image} alt="nthg" />
                                    </div>
                                    <div className="card-footer">
                                        <button type="button" className="btn btn-primary btn-block">De-Allocate Cabin</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                {/* </div>
                </div> */}
            </React.Fragment>
        )
    }
}

export default DeAllocateCabin;