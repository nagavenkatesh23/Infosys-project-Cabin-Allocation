import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import Admin from "./admin";
import 'bootstrap/dist/css/bootstrap.min.css';
import Manager from "./manager"
import AllocateUser from "./allocateuser"
import AllocateCabin from "./allocatecabin"
const url = "http://localhost:3000/cabinDetails"

export default class GAllocateTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            availableCabin: [],
            deallocate:false,
            allocate:false,

            formValid: {
                empId: "",
                buttonActive: true
            },
            errorMessage: "",
            successMessage: "",
            goBack: false
        }
    }

    handleSubmit = event => {
        event.preventDefault();
        this.getAllCabinDetails();
    }

    getAllCabinDetails = () => {
        // let empId = this.state.form.empId
        let url = `http://localhost:1050/GcabinDetails`
        // console.log("in axios"+empId)
        axios.get(url)
            .then(res => {
                console.log(res.data)
                this.setState({ availableCabin: res.data })
                this.setState({ errorMessage: "" });
            })
            .catch(err => {
                let errMsg = err.response ? err.response.data.message : "Server Error"
                console.log(errMsg)
                this.setState({ errorMessage: errMsg })
                this.setState({ successMessage: "" });
            })
    }

    render() {
        if (this.state.availableCabin == null) {
            return <Manager></Manager>
        }
        else if (this.state.allocate == true) {
            return <AllocateUser></AllocateUser>
        }
        else {
            return (
                <React.Fragment>
                    <div className="container-fluid">
                        <div className="mt-4">
                            <div>
                                <button name="goBack" type="submit" className="float-right btn btn-warning btn-md" onClick={() => { this.setState({ availableCabin: null }) }}>Go Back</button>
                            </div>
                        </div>
                        <div className="row mt-4">
                            <div className="col-lg-7  offset-lg-5">
                                <form onSubmit={this.handleSubmit}>
                                    <button type="submit" className="btn btn-primary" >View Cabin Details</button>
                                </form>
                            </div>
                            <span name="successMessage" className="text-danger">{this.state.successMessage}</span>
                            <span name="errorMessage" className="text-danger">{this.state.errorMessage}</span>
                        </div>
                        {
                            this.state.availableCabin != "" ? (
                                <div className="mt-3">
                                    <div className="text-center"><b>CABIN DETAILS</b></div>
                                    <br />
                                    {
                                        <table className="table table-dark table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Cabin Number</th>
                                                    <th>Cabin Wing</th>
                                                    <th>Cabin Floor</th>
                                                    <th>Allocation Status</th>
                                                    <th>Allocated User</th>
                                                    <th>Allocate/Deallocate</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    this.state.availableCabin.map((data, i) => {
                                                        console.log(data);
                                                        return (
                                                            <tr key={i}>
                                                                <td>{this.state.availableCabin[i].cabinNumber}</td>
                                                                <td>{this.state.availableCabin[i].cabinWing}</td>
                                                                <td>{this.state.availableCabin[i].cabinFloor}</td>
                                                                <td>{this.state.availableCabin[i].allocationStatus}</td>
                                                                <td>{this.state.availableCabin[i].allocatedUser}</td>
                                                                {
                                                                    (this.state.availableCabin[i].allocationStatus == "Filled") ?
                                                                       <td> <button name="De-Allocate User" type="submit" className="btn btn-block btn-primary" onClick={() => { this.setState({ deallocate: true }) }}>De-Allocate User</button></td>
                                                                        :
                                                                         <td>   <button name="Allocate User" type="submit" className="btn btn-block btn-primary" onClick={() => { this.setState({ allocate: true }) }}>Allocate User</button></td>
                                                                }
                                                            </tr>
                                                        )
                                                    })
                                                }
                                            </tbody>
                                        </table>
                                    }
                                </div>
                            ) : null
                        }
                    </div>
                    {/* {console.log(this.state)} */}
                </React.Fragment>
            )
        }
    }
}
