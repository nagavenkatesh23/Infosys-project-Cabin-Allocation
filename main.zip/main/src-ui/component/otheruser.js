import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
// const url = "http://localhost:3000/user/empId"
// const url1 = "http://localhost:1050/user/cabinNumber"
// const url2 = "http://localhost:1050/user/empName"

export default class OtherUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            availableCabin: [],
            form: {
                empId: "",
                cabinNumber: "",
                empName: ""
            },
            formErrorMessage: {
                empId: "",
                cabinNumber: "",
                empName: ""
            },
            formValid: {
                empId: "",
                cabinNumber: "",
                empName: "",
                buttonActive: false
            },
            errorMessage: "",
            successMessage: ""
        }
    }

    handleSubmit = event => {
        event.preventDefault();
        this.getUserDetails();
    }

    getUserDetails = () => {
        let empId = this.state.form.empId;
        let url = `http://localhost:1050/user/${empId}`
        let url1 = `http://localhost:1050/user1/${empId}`
        let url2 = `http://localhost:1050/user2/${empId}`
        // console.log(this.state.form)
        let urlused;
        let regex1 = new RegExp(/^(G|L1|L2){1,2}-[A-Z]{1}[0-9]{2,3}$/);   // cabin-number
        let regex2 = new RegExp(/^[A-z]{2,}$/);    // name

        if (regex1.test(this.state.form.empId)) {
            urlused = url1;
        }
        else if (regex2.test(this.state.form.empId)) {
            urlused = url2;
        }
        else {
            urlused = url;
        }
        console.log(urlused)
        // console.log("in axios"+empId)
        axios.get(urlused)
            .then(res => {
                // console.log(res.data)
                this.setState({ availableCabin: res.data, errorMessage: "" })
            })
            .catch(err => {
                let errMsg = err.response ? err.response.data.message : "Server Error"
                // console.log(errMsg)
                this.setState({ errorMessage: errMsg, availableCabin: "", successMessage: "" })
            })
    }

    handleChange = (event) => {
        // console.log(event.target.name)
        // console.log(event.target.value)
        const name = event.target.name;
        const value = event.target.value;
        this.setState({ form: { ...this.state.form, [name]: value },availableCabin:[],errorMessage:null});
        this.validateField(name, value);
    };

//Validation for employee Id,cabinnumber,employee name
    validateField = (fieldName, value) => {
        let message = "";
        let validity = false;
        if (fieldName == "empId") {
            let regex = new RegExp(/^[1-9][0-9]{5}$/);
            let regex1 = new RegExp(/^(G|L1|L2)-[A-Z][0-9]{2,3}$/);
            let regex2 = new RegExp(/^[A-z]{2,}$/);
            value === "" ? message = "Field required" : regex.test(value) ? message = "" : regex1.test(value) ? message = "" : regex2.test(value) ? message = "" : message = "enter correct employee id or employee name or cabin number "
        }
        let formErrorMessageObj = this.state.formErrorMessage;
        formErrorMessageObj[fieldName] = message
        // console.log(formErrorMessageObj)
        this.setState({ formErrorMessage: formErrorMessageObj })
        validity = message ? false : true
        let formValidObj = this.state.formValid
        formValidObj[fieldName] = validity
        formValidObj.buttonActive = formValidObj.empId || formValidObj.cabinNumber || formValidObj.empName;
        this.setState({ formValid: formValidObj })
        // console.log(this.state.form)
    }
//===================== Form to view employee details based on empId,emp name, cabin number ====================
    render() {    
        return (
            <React.Fragment>
                <div className="container-fluid">
                <h1><i>{this.props.uname}</i></h1>
                    <div className="row mt-5">
                        <div className="col-lg-4 offset-lg-4">
                            <div className="card bg-card bg-dark custom-card text-light ">
                                <div className="card-body">
                                    <form onSubmit={this.handleSubmit}>
                                        <div className="form-group">
                                            <input type="text" name="empId" id="empId" placeholder="Enter Emp-Id or Cabin-Number or Emp-Name" onChange={this.handleChange} className="form-control" />
                                        </div>
                                        <span name="empId" className="text-danger ">
                                            {this.state.formErrorMessage.empId}
                                        </span><br />
                                        <button type="submit" className="btn btn-primary" disabled={!this.state.formValid.buttonActive}>View Details</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <span name="successMessage" className="text-danger">{this.state.successMessage}</span>
                        <span name="errorMessage" className="text-danger">{this.state.errorMessage}</span>
                    </div>
                    {
                       this.state.availableCabin != ""  ? (
                            <div className="mt-3">
                                <div className="text-center"><b>EMPLOYEE DETAILS</b></div>
                                <br />
                                {
                                    <table className="table table-dark table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Employee Id</th>
                                                <th>Employee Name</th>
                                                <th>User Name</th>
                                                <th>Designation</th>
                                                <th>Stream</th>
                                                <th>Cabin Number</th>
                                                <th>Cabin Wing</th>
                                                <th>Cabin Floor</th>
                                                <th>Allocation Status</th>
                                                <th>Allocated User</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>{this.state.availableCabin[0].empId}</td>
                                                <td>{this.state.availableCabin[0].empName}</td>
                                                <td>{this.state.availableCabin[0].userName}</td>
                                                <td>{this.state.availableCabin[0].designation}</td>
                                                <td>{this.state.availableCabin[0].stream}</td>
                                                <td>{this.state.availableCabin[1][0].cabinNumber}</td>
                                                <td>{this.state.availableCabin[1][0].cabinWing}</td>
                                                <td>{this.state.availableCabin[1][0].cabinFloor}</td>
                                                <td>{this.state.availableCabin[1][0].allocationStatus}</td>
                                                <td>{this.state.availableCabin[1][0].allocatedUser}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                }
                            </div>
                        ) : null
                    }
                </div>
                {/* {console.log(this.state)} */}
            </React.Fragment>
        )
    }
  
}
