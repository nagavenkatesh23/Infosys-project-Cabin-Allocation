import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import Admin from "./admin";
import 'bootstrap/dist/css/bootstrap.min.css';

class DeletedDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            deletedDetails: [],
            form: {
                details: ""
            },
            formErrorMessage: {
                details: ""
            },
            formValid: {
                details: "",
                buttonActive: false
            },
            errorMessage: "",
            successMessage: ""
        }
    }

    handleSubmit = event => {
        event.preventDefault();
        this.getDeletedDetails();
    }

// Axios to get Deleted Details from Backend
    getDeletedDetails = () => {
        let details = this.state.form.details
        let url = `http://localhost:1050/admincabin/${details}`
        let url1 = `http://localhost:1050/adminempid/${details}`
        let url2 = `http://localhost:1050/adminename/${details}`

        let regex = new RegExp(/^[1-9][0-9]{5}$/);   // employee id validation
        let regex1 = new RegExp(/^(G|L1|L2)-[A-Z][0-9]{2,3}$/);  // cabin number validation
        let urlused;
        if (regex.test(this.state.form.details)) {
            urlused = url1;
        }
        else if (regex1.test(this.state.form.details)) {
            urlused = url;
        }
        else {
            urlused = url2;
        }
        axios.get(urlused)
            .then(res => {
                // console.log(res.data)
                this.setState({ deletedDetails: res.data, errorMessage: "" })
            })
            .catch(err => {
                let errMsg = err.response ? err.response.data.message : "Server Error"
                this.setState({ errorMessage: errMsg, deletedDetails: "", successMessage: "" })
            })
    }

    handleChange = (event) => {
        // console.log(event.target.name)
        // console.log(event.target.value)
        const name = event.target.name;
        const value = event.target.value;
        this.setState({ form: { ...this.state.form, [name]: value },deletedDetails: [],errorMessage:null});
        this.validateField(name, value);
    };

// Validation for empname, empId, cabin number
    validateField = (fieldName, value) => {
        let message = "";
        let validity = false;
        if (fieldName == "details") {
            let regex = new RegExp(/^[1-9][0-9]{5}$/);  // employee id validation
            let regex1 = new RegExp(/^(G|L1|L2)-[A-Z][0-9]{2,3}$/);  // cabin number validation
            let regex2 = new RegExp(/^[A-z]*$/);   // employee name validation
            value === "" ? message = "Field required" : regex.test(value) ? message = "" : regex1.test(value) ?
                message = "" : regex2.test(value) ? message = "" : message = "enter correct cabin number or employee id or employee name"
        }
        let formErrorMessageObj = this.state.formErrorMessage;
        formErrorMessageObj[fieldName] = message
        // console.log(formErrorMessageObj)
        this.setState({ formErrorMessage: formErrorMessageObj })
        validity = message ? false : true
        let formValidObj = this.state.formValid
        formValidObj[fieldName] = validity
        formValidObj.buttonActive = formValidObj.details
        this.setState({ formValid: formValidObj })
        // console.log(this.state.form)
    }

//============================ Form to view all Deleted Details in a tabular format ==============================
    render() {
        if (this.state.deletedDetails == null) {
            return <Admin></Admin>;
        }
        else {
            return (
                <React.Fragment>
                    <div className="container-fluid">
                        <div className="mt-4">
                            <div>
                                <button name="goBack" type="submit" className="float-right btn btn-warning" onClick={() => { this.setState({ deletedDetails: null }) }}>Go Back</button>
                            </div>
                        </div>
                        <div className="row mt-5">
                            <div className="col-lg-5 offset-lg-4">
                                <div className="card bg-card bg-dark custom-card text-light ">
                                    <div className="card-body">
                                        <form onSubmit={this.handleSubmit}>
                                            <div className="form-group" style={{ align: "center" }}>
                                                <input type="text" name="details" id="details"
                                                    placeholder="Enter Emp-Id or Cabin-Number or Emp-Name" className="form-control"
                                                    onChange={this.handleChange} />
                                            </div>
                                            <span name="details" className="text-danger ">
                                                {this.state.formErrorMessage.details}
                                            </span><br />
                                            <button type="submit" className="btn btn-primary " disabled={!this.state.formValid.buttonActive}>View Details</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <span name="successMessage" className="text-danger">{this.state.successMessage}</span>
                            <span name="errorMessage" className="text-danger">{this.state.errorMessage}</span>
                        </div>
                        {
                            this.state.deletedDetails != "" ? (
                                <div className="mt-3">
                                    <div className="text-center"><b>EMPLOYEE DETAILS</b></div> {/* text-info can also be used */}
                                    <br />
                                    {
                                        <table className="table table-dark table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Employee Id</th>
                                                    <th>Employee Name</th>
                                                    <th>User Name</th>
                                                    <th>Designation</th>
                                                    <th>Stream</th>
                                                    <th>Cabin Number</th>
                                                    <th>Allocated Date</th>
                                                    <th>De-Allocated Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>{this.state.deletedDetails.empId}</td>
                                                    <td>{this.state.deletedDetails.empName}</td>
                                                    <td>{this.state.deletedDetails.userName}</td>
                                                    <td>{this.state.deletedDetails.designation}</td>
                                                    <td>{this.state.deletedDetails.stream}</td>
                                                    <td>{this.state.deletedDetails.cabinNumber}</td>
                                                    <td>{this.state.deletedDetails.allocatedDate}</td>
                                                    <td>{this.state.deletedDetails.deallocatedDate}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    }
                                </div>
                            ) : null
                        }
                    </div>
                    {/* {console.log(this.state)} */}
                </React.Fragment>
            )
        }
    }
}
export default DeletedDetails