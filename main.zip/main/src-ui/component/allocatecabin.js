import React, { Component } from "react";
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import image from "./img10.jpg"
import Manager from "./manager"
import GAllocateTable from "./Gallocatetable"
import L1AllocateTable from "./L1allocatecabin"
import L2AllocateTable from "./L2allocatecabin"

class AllocateCabin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            allocatecabin: [],
            viewgrounddetail:false,
            viewlevelonedetail:false,
            viewleveltwodetail:false

        }
    }
    
    render() {
        if (this.state.allocatecabin == null) {
            return <Manager></Manager>
        }
        else if (this.state. viewgrounddetail == true) {
            return <GAllocateTable></GAllocateTable>
        }
        else if(this.state.  viewlevelonedetail == true){
            return <L1AllocateTable></L1AllocateTable>
        }
        else if(this.state.  viewleveltwodetail== true){
            return <L2AllocateTable></L2AllocateTable>
        }
        return (
            <React.Fragment>
                <div className="container mt-5">
                    <div className="mt-4">
                        <div>
                            <button name="goBack" type="submit" className="float-right btn btn-warning" onClick={() => { this.setState({ allocatecabin : null }) }}>Go Back</button>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="card-deck">
                                <div className="card ">
                                    <div className="card-header"><h4 className="text-center">Ground Floor</h4></div>
                                    <div className="card-body">
                                        <img width="100%" height="180" src={image} alt="nthg" />
                                    </div>
                                    <div className="card-footer">
                                        <button type="button" className="btn btn-primary btn-block" onClick={() => { this.setState({ viewgrounddetail: true }) }}>View Cabins</button>
                                    </div>
                                </div>
                                <div className="card ">
                                    <div className="card-header"><h4 className="text-center">Level 1</h4></div>
                                    <div className="card-body">
                                        <img width="100%" height="180" src={image} alt="nthg" />
                                    </div>
                                    <div className="card-footer">
                                        <button type="button" className="btn btn-primary btn-block" onClick={() => { this.setState({ viewlevelonedetail: true }) }}>View Cabins</button>
                                    </div>
                                </div>
                                <div className="card ">
                                    <div className="card-header"><h4 className="text-center">Level 2</h4></div>
                                    <div className="card-body">
                                        <img width="100%" height="180" src={image} alt="nthg" />
                                    </div>
                                    <div className="card-footer">
                                        <button type="button" className="btn btn-primary btn-block" onClick={() => { this.setState({ viewleveltwodetail: true }) }}>View Cabins</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* </div>
                </div> */}
            </React.Fragment>
        )
    }
}

export default AllocateCabin;